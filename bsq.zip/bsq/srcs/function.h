#ifndef FUNTION_H
# define FUNTION_H

#include "ft_atoi.c"
#include "ft_string.c"


int	ft_atoi(char *s);
int	ft_strlen(char *s);

#endif