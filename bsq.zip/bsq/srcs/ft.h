#ifndef FT_H
# define FT_H

#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include "function.h"
#include "map_read.h"

#endif